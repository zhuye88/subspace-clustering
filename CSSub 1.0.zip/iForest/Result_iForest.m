classdef Result_iForest < handle
    properties
        mass = [];
    end
    
    methods
        
        function result = Result_iForest(n)
            result.mass = zeros(n,1);
        end
        
    end
    
end
    